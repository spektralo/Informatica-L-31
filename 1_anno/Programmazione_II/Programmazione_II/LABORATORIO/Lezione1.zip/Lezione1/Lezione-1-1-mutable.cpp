struct Foo
{
	mutable int value;
	int secondvalue;
};

int main()
{
	const struct Foo foo = { 10, 100 };
	foo.value = 200;
	//foo.secondvalue = 100; error
}