#include <iostream>

using namespace std;

int* readData()
{
	int* arr = new int[3] {0, 0, 0};
	int index = 0;
	do
	{
		int i;
		cin >> i;
		if (i > 0)
		{
		  if (index == 2)
			{
				if (i > arr[0] + arr[1])
				{
					arr[2] = i;
					index++;
				}
			}
		  else
		  {				
				arr[index] = i;
				index++;
		  }
		}
	}while (index != 3);
	return arr;
}

int main()
{
	int* arr = readData();
	cout << "Inserted " << arr[0] << " " << arr[1] << " " << arr[2] << endl;
	delete[] arr;
	return 0;
}