/*
   Leggere il contenuto del file "es1.txt" tokenizzandolo sul simbolo "," e ".".
   I token devono essere salvati su un array. Scrivere sul file chiamato "es1-out.txt" il numero di token
   ottenuti
*/

#include <iostream>
#include <string>
#include <fstream>
#include <vector>

using namespace std;

static int computeTokensNum(const string &filename)
{
	ifstream file(filename);
	int num = 0;
	if (file.is_open())
	{	
		char c;			
		while (file.get(c))
		{		
		  if(c == '.' || c == ',')			   
			num++;	
			   
		}
	}	
	file.close();
	return num;
}

static void tokenize(vector<string>* tokens, const string& filename)
{
	ifstream file(filename);
	int i = 0;
	if (file.is_open())
	{		
		string token = "";
		char c;
		while (file.get(c))
		{						
			if (c != '\n' && c != '\r')
			{				
				token += c;
				if (c == '.' || c == ',')
				{
					tokens->at(i) = token;					
					i++;
					token = "";					
				}
			}
		}
		cout << token << endl;
	}
	file.close();
}

static void writeNumTokens(const string name, const int num)
{
	ofstream file(name);
	file<<num;
	file.close();
}

int main()
{
	string filename = "/mnt/c/Users/danie/Source/Repos/dfsantamaria/Programmazione2/Esercizi/es1.txt";	
	string fileout = "/mnt/c/Users/danie/Source/Repos/dfsantamaria/Programmazione2/Esercizi/es1-out.txt";
	int num = computeTokensNum(filename);	
	if (num > 0)
	{
		//string* tokens=new string[num];
		vector<string>* tokens= new vector<string>(num);
		cout << num << endl;
		tokenize(tokens, filename);
		for (int i = 0; i < num; i++)
		{	
			cout << i << " "<< tokens->at(i) << endl;
		}
		writeNumTokens(fileout, num);
		delete tokens;
	}	
	return 0;
}
