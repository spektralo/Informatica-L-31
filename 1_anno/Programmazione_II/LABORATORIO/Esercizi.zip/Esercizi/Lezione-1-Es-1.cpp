#include<iostream>

using namespace std;

const struct 
{
	string vowels="aAeEiIoOuU";
} vowels;

int countVowel(string& message)
{
  int counter = 0;
  for (char c : message)
   for (char v : vowels.vowels)
	if (c == v)
	 {
	  counter++;
	  break;
	 }
  return counter;
}

int main()
{
	string message;
	int counter = 0;
	getline(cin, message);
	cout << message << endl;
	counter = countVowel(message);
	cout << counter << endl;
	return 0;
}