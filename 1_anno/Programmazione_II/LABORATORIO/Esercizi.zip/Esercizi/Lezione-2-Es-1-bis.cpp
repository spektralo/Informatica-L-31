#include<iostream>
#include<fstream>

using namespace std;

void expand(string**& arr, const size_t& oldcapacity, const size_t& newcapacity)
{
	string** newarr = new string * [newcapacity];
	for (size_t i = 0; i < oldcapacity; i++)
	{
		newarr[i] = arr[i];
	}
	delete arr;
	arr = newarr;
}

void store(string* s, string**& arr, size_t& capacity, size_t& size)
{
	if (size == capacity)
	{
		capacity *= 2;
		expand(arr, size, capacity);
	}
	arr[size] = s;
	size++;

}


void tokenize(const string& source, string**& arr, size_t& size, size_t& capacity)
{
	ifstream stream(source);
	if (stream.is_open())
	{
		string acc;
		char c;
		while (stream.get(c))
		{
			if (c != '\n' && c != '\r' && (acc.size() != 0 || c != ' '))
				acc += c;
			if (c == ',' || c == '.')
			{
				string* token = new string(acc);
				store(token, arr, capacity, size);
				acc.clear();
			}
		}
		stream.close();
	}
}



int main()
{
	size_t capacity = 10;
	size_t size = 0;
	string** arr = new string * [capacity];
	tokenize("/mnt/c/Users/danie/source/repos/dfsantamaria/Programmazione2/Esercizi/es1.txt", arr, size, capacity);
	for (size_t i = 0; i < size; i++)
		cout << *arr[i] << endl;

	return 0;
}